
var client = mqtt.connect($('#broker').val());

function connect(){
  
  var status = $('#status');
  
  status.val("Connecting...."); 

  client.on('connect', function () {
    status.val("Connected!");
  })

  topic = $("#pub_topic").val()
  message = $('#pub_payload').val()

  client.on('message', function (topic, message){
    console.log(topic);
    let date = new Date();

    if (topic == $('#sub-topic').val()) {

      $("#incomingTable").prepend(
        "<tr><td>" + topic + 
        "</td><td>" + message + 
        "</td><td>"+ date.toDateString()+ 
        " " +date.toLocaleTimeString() +
        "</td></tr>"
      );

    }
    console.log(topic);
  })

}

function publish(){
  
  var date = new Date;
  var pub_topic = $('#pub_topic'); 
  var pub_payload = $('#pub_payload')
  if( pub_topic.val()  != "" && pub_payload.val() != ""){

      client.publish( pub_topic.val(), pub_payload.val());

      $('#pubTable').prepend(
    
        "<tr><td>" + pub_topic.val() + "</td><td>" +pub_payload.val() + "</td><td>"+ date.toDateString()+ " " +date.toLocaleTimeString() +"</td></tr>"

      );

  }else{
    alert("Please input topic and payload");
  }

}


function subscribe(){

  var date = new Date;
  var sub_topic = $('#sub-topic'); 

  if( sub_topic.val()  != ""){

    client.subscribe( sub_topic.val(), (err) => {

      if(err){
        console.log("Error in subscribing topic!");
      }

    });

    $('#subscribeTable').prepend(
  
      "<tr><td>" + sub_topic.val() + "</td><td>"+ date.toDateString()+ " " +date.toLocaleTimeString() +"</td></tr>"

    );

}else{
  alert("Please input topic.");
}

}
